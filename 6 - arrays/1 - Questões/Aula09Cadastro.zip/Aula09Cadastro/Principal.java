
package Aula09Cadastro;

public class Principal {
    
    public static void main(String[] args) {
        
        Veiculo c1 = new Veiculo("Fiat", "Idea", "Gasolina", 2015);
        Veiculo c2 = new Veiculo("Toyota", "Corolla", "Gasolina", 2020);
        Veiculo c3 = new Veiculo("Ford", "Focus", "Gasolina", 2009);
        Veiculo c4 = new Veiculo("GM", "Onix", "Alcool/Gasolina", 2017);
        
        //Popular o arrayList
        BancoInfo op = new BancoInfo();
        op.inserirItemArray(c1);
        op.inserirItemArray(c2);
        op.inserirItemArray(c3);
        op.inserirItemArray(c4);
        
        op.listarItensArray();
        op.removerItemArray(1);
        
        System.out.println("Nova lista!");
        op.listarItensArray();
        
        op.apagarItensArray();
        op.listarItensArray();
        
    }
}
