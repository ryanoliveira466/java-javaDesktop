
package Aula09Cadastro;

import java.util.ArrayList;


public class BancoInfo {
    
    ArrayList<Veiculo> itensBanco = new ArrayList<>();
    
    //Adicionar itens na ArrayList
    public void inserirItemArray(Veiculo novoItem){
        itensBanco.add(novoItem);
        System.out.println("Item inserido com suceso!");
    }
    
    //Remover itens na ArrayList
    public void removerItemArray(int index){
        itensBanco.remove(index);
        System.out.println("Item removido com suceso!");
    }
        
    //Apagar todos itens da ArrayList
    public void apagarItensArray(){
        itensBanco.clear();
        System.out.println("Lista totalmente apagada com sucesso!");
    }
        
    //Listar os itens contidos na Array - Apresentação
    public void listarItensArray(){
        for(int i=0; i<itensBanco.size(); i++){
            System.out.println("Marca: " + itensBanco.get(i).getMarca());
            System.out.println("Modelo: " + itensBanco.get(i).getModelo());
            System.out.println("Combustivel: " + itensBanco.get(i).getCombustivel());
            System.out.println("Ano: " + itensBanco.get(i).getAno());
            
        }
    
    }
    
    
    //Gravar informações da Array em arquivo TXT
    
    //Leitura das informações do arrayList.
    
}
